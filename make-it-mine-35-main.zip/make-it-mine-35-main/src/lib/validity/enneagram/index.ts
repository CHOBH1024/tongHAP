export { enneagramData } from '../enneagram';
